package com.lite.launcher

import android.app.Activity
import android.content.*
import android.os.Build
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Executors.newSingleThreadExecutor()
    private lateinit var adapter: AppAdapter

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = load()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        adapter = AppAdapter { app ->
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(app.cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        findViewById<RecyclerView>(R.id.grid).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = this@MainActivity.adapter
            setHasFixedSize(true)
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(receiver, f)
        load()
    }

    // lista de apps carregada em background, nunca na thread da UI
    private fun load() = bg.execute {
        val pm = packageManager
        val list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { ri ->
                AppItem(ri.loadLabel(pm).toString(),
                    ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)) { ri.loadIcon(pm) }
            }.sortedBy { it.label.lowercase() }
        runOnUiThread { adapter.submit(list) }
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        findViewById<RecyclerView>(R.id.grid).scrollToPosition(0) // botão Home volta ao topo
    }

    @Deprecated("Deprecated")
    override fun onBackPressed() {} // launcher não fecha

    override fun onDestroy() { unregisterReceiver(receiver); bg.shutdown(); super.onDestroy() }
}
