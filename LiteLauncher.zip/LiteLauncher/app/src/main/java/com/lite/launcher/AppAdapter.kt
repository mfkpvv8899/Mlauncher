package com.lite.launcher

import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class AppItem(val label: String, val cn: ComponentName, val loadIcon: () -> Drawable)

class AppAdapter(private val onClick: (AppItem) -> Unit) : RecyclerView.Adapter<AppAdapter.VH>() {
    private var items = emptyList<AppItem>()
    private val cache = LruCache<String, Drawable>(150)   // ícones em memória
    private val io = Executors.newFixedThreadPool(2)       // ícones fora da thread principal
    private val ui = Handler(Looper.getMainLooper())

    fun submit(list: List<AppItem>) { items = list; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_app, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val a = items[pos]
        val key = a.cn.flattenToString()
        h.label.text = a.label
        h.itemView.setOnClickListener { onClick(a) }
        h.icon.tag = key
        val cached = cache.get(key)
        if (cached != null) { h.icon.setImageDrawable(cached); return }
        h.icon.setImageDrawable(null)
        io.execute {
            val d = a.loadIcon()
            cache.put(key, d)
            ui.post { if (h.icon.tag == key) h.icon.setImageDrawable(d) }
        }
    }
}
